declare module "parquetjs-react";
declare module "@duckdb/duckdb-wasm/dist/duckdb-browser-mvp.worker.js";
declare module "@duckdb/duckdb-wasm/dist/duckdb-browser-eh.worker.js";
