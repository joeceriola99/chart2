import React from "react";
import { Box, Button, Divider } from "@mui/material";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import ParquetFileUploader from "./ParquetFileUploader";

const dataSet = [
  {
    id: 1000,
    label: "1K Data",
    description:
      "Small Dataset - Tests basic responsiveness and rendering speed for typical small-sclae applications",
  },
  {
    id: 10000,
    label: "10K Data",
    description:
      "Medium Dataset - Evaluates Performance under more demanding conditions, suitable for interactive dashboards and data analysis tools that require moderate data",
  },
  {
    id: 50000,
    label: "50K Data",
    description:
      "Medium Dataset - Evaluates Performance under more demanding conditions, suitable for interactive dashboards and data analysis tools that require moderate data",
  },
  {
    id: 100000,
    label: "100K Data",
    description:
      "Large Dataset - Pushes the limits of what's practical in a web environment, testing the library's optimization and for handling large datasets, such as data aggregation, canvas rendering, and responsiveness.",
  },
  {
    id: 500000,
    label: "500K Data",
    description:
      "Large Dataset - Pushes the limits of what's practical in a web environment, testing the library's optimization and for handling large datasets, such as data aggregation, canvas rendering, and responsiveness.",
  },
  {
    id: 1000000,
    label: "1M Data",
    description:
      "Extreme Dataset - Not Typically practical for real-world applications due to browser limitations and user experience consideration, but useful for stress-testing library's upperl imits",
  },
];

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`vertical-tabpanel-${index}`}
      aria-labelledby={`vertical-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `vertical-tab-${index}`,
    "aria-controls": `vertical-tabpanel-${index}`,
  };
}

interface ChartFiltersProps {
  setJsonData: (value: any) => void;
  setLoading: (value: any) => void;
  loading: boolean;
}

const ChartFilters = ({
  setJsonData,
  setLoading,
  loading,
}: ChartFiltersProps) => {
  const [value, setValue] = React.useState(0);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  const generateData: (points: number) => Promise<any> = (points: number) => {
    return new Promise((resolve) => {
      return setTimeout(() => {
        const data = [];
        for (let index = 0; index < points; index++) {
          const minutes = 60 * index;
          const timeStamp = Math.floor(Date.now() / 1000) + minutes;
          const value = Math.floor(Math.random() * (100000 - 100 + 1) + 100);
          data.push([timeStamp, value]);
        }
        resolve(data);
      }, 1000);
    });
  };

  const handleGenerate = async (type: "parquet" | "datasets", value: any) => {
    setLoading(true);
    if (type === "datasets") {
      const data = await generateData(value);
      setJsonData(data);
      setLoading(false);
    } else {
    }
  };
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        gap: 2,
      }}
    >
      {/* Data sets Tabs */}
      <Box
        sx={{
          flexGrow: 1,
          bgcolor: "background.paper",
          display: "flex",
          height: 224,
        }}
      >
        <Tabs
          orientation="vertical"
          variant="scrollable"
          value={value}
          onChange={handleChange}
          aria-label="Vertical tabs example"
          sx={{ borderRight: 1, borderColor: "divider" }}
        >
          {dataSet.map((set, index) => (
            <Tab key={index} label={set.label} {...a11yProps(index)} />
          ))}
          ;
        </Tabs>
        {dataSet.map((set, index) => (
          <TabPanel key={index} value={value} index={index}>
            <Box>
              <Typography maxWidth={300}>{set.description}</Typography>
              <Button
                variant="contained"
                sx={{
                  mt: 2,
                }}
                onClick={() => handleGenerate("datasets", set.id)}
              >
                Generate
              </Button>
            </Box>
          </TabPanel>
        ))}
        ;
      </Box>
      <Divider orientation="vertical" flexItem>
        OR
      </Divider>
      {/* Performance Test */}
      <ParquetFileUploader
        setLoadingJsonData={setLoading}
        setJsonData={setJsonData}
      />
    </Box>
  );
};

export default ChartFilters;
