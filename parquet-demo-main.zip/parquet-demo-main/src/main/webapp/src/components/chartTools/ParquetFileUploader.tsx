import { initializeDuckDB } from "@/duckDBService/metrics";
import { Box, Button } from "@mui/material";
import moment from "moment";
import React, { ChangeEventHandler, useEffect, useState } from "react";

interface ParquetFileUploaderProps {
  setJsonData: (value: any) => void;
  setLoadingJsonData: (value: any) => void;
}
const ParquetFileUploader = ({
  setJsonData,
  setLoadingJsonData,
}: ParquetFileUploaderProps) => {
  const [loading, setLoading] = useState(false);
  const handleUpload: React.ChangeEventHandler<HTMLInputElement> = async (
    event
  ) => {
    setLoading(true);
    setLoadingJsonData(true);
    const files = event.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const arrayBuffer = await file.arrayBuffer();
    const startTime = performance.now();

    try {
      const duckDb = await initializeDuckDB();
      await duckDb.registerFileBuffer(
        "buffer.parquet",
        new Uint8Array(arrayBuffer)
      );

      const connect = await duckDb.connect();
      console.log(file.name, "name");
      await connect.query(
        `CREATE OR REPLACE TABLE new_table AS SELECT * FROM "buffer.parquet"`
      );

      await connect.query(
        `COPY (SELECT * FROM new_table) TO '${file.name}.json'`
      );

      const result = await connect.query(
        `SELECT * FROM  read_json_auto('${file.name}.json', FORMAT='auto')`
      );
      const data: any[] = result ? JSON.parse(result?.toString()) : [];
      const datasets = data.map(
        (item: { myString: string; myInteger: number; myDateTime: string }) => {
          const transformDate = moment(item.myDateTime, "YYYY-MM-DD HH:mm:sz");
          const timeStamp = transformDate.unix();
          return [timeStamp, item.myInteger];
        }
      );
      const endTime = performance.now();
      setJsonData(datasets);
      setLoading(false);
      setLoadingJsonData(false);
    } catch (error) {
      setLoading(false);
      setLoadingJsonData(false);
    }
  };
  return (
    <Box
      sx={{
        height: 224,
        display: "grid",
        placeItems: "center",
      }}
    >
      <input
        accept=".parquet"
        id="upload-button"
        type="file"
        style={{
          display: "none",
        }}
        onChange={handleUpload}
      />
      <label htmlFor="upload-button">
        <Button component="span" variant="contained" disabled={loading}>
          Upload parquet file
        </Button>
      </label>
    </Box>
  );
};

export default ParquetFileUploader;
