import React, { useEffect, useState } from "react";
import { render } from "react-dom";
import HighchartsReact from "highcharts-react-official";
import Highcharts, { ChartOptions } from "highcharts";
import { Box, Container, Divider, Typography } from "@mui/material";

interface HighchartsLineChartProps {
  data: [number, string][];
}
const HighchartsLineChart = ({ data }: HighchartsLineChartProps) => {
  const [loadTime, setLoadTime] = useState<number>(0);
  const [startTime] = useState(performance.now());
  const [chartRendered, setChartRendered] = useState(false);

  const options = {
    chart: {
      type: "line",
      zoomType: "x",
      height: 400,
      events: {
        load: () => {
          const endTime = performance.now();
          console.log("rendered", endTime);
          if (!chartRendered) {
            setLoadTime(endTime - startTime);
            setChartRendered(true);
          }
        },
      },
    },
    boost: {
      useGPUTranslations: true,
      usePreAllocated: true,
    },
    title: {
      text: "Highcharts Sample",
      align: "left",
    },
    xAxis: {
      type: "datetime",
      title: {
        text: "Date & Time",
      },
    },
    yAxis: {
      title: {
        text: "Metric Data",
      },
    },
    series: [
      {
        name: "Sample Data",
        data: data,
        turboThreshold: 50000,
      },
    ],
    plotOptions: {
      series: {
        animation: false,
      },
    },
    tooltip: {
      enabled: false,
    },
    credits: {
      enabled: false,
    },
  };

  // useEffect(() => {
  //   const startTime = performance.now();

  //   const simulateChartLoad = () => {
  //     return new Promise((resolve) =>
  //       setTimeout(resolve, Math.random() * 1000 + 500)
  //     );
  //   };

  //   simulateChartLoad().then(() => {
  //     const endTime = performance.now();
  //     const timeTaken = endTime - startTime;
  //     setLoadTime(timeTaken);
  //   });
  // }, []);
  return (
    <Container
      maxWidth="lg"
      sx={{
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Typography>
        Load Time: <strong>{(loadTime / 1000).toFixed(2)}s</strong>
      </Typography>
      <HighchartsReact highcharts={Highcharts} options={options} />
      <Typography marginY={2}>
        You should consider using HighCharts if you have a large team with
        complex data visualization needs. Since they have fairly good amount of
        integrations and email support, integrating it in your projects won't be
        a huge a issue for you.
      </Typography>
    </Container>
  );
};
export default HighchartsLineChart;
