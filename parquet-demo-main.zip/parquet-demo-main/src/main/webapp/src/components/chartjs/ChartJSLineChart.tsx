import React, { useEffect, useRef, useState } from "react";
import { render } from "react-dom";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  TimeScale,
  TimeSeriesScale,
  Filler,
  Decimation,
  ChartOptions,
} from "chart.js";
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  TimeScale,
  TimeSeriesScale,
  Filler,
  Title,
  Tooltip,
  Legend,
  Decimation
);

import { Box, Container, Typography } from "@mui/material";

interface ChartJSLineChartProps {
  data: [number, string][];
}
const ChartJSLineChart = ({ data }: ChartJSLineChartProps) => {
  const [loadTime, setLoadTime] = useState<number | null>(null);
  const [startTime] = useState(performance.now());
  const [chartRendered, setChartRendered] = useState(false);
  const [chartData, setChartData] = useState<{
    labels: any[];
    datasets: any[];
  }>({
    labels: [],
    datasets: [],
  });

  useEffect(() => {
    setChartData({
      labels: data.map((item) => new Date(item[0]).toLocaleDateString()),
      datasets: [
        {
          label: "Chart JS Sample",
          data: data.map((item) => item[1]),
          fill: false,
          tension: 0.1,
          borderColor: "red",
        },
      ],
    });
  }, [data]);

  const options: ChartOptions<"line"> = {
    responsive: true,
    animation: {
      onComplete(event) {
        if (!chartRendered) {
          const endTime = performance.now();
          setLoadTime(endTime - startTime);
          setChartRendered(true);
        }
      },
    },
    normalized: true,
    maintainAspectRatio: false,
    interaction: {
      mode: "nearest",
      axis: "x",
      intersect: false,
    },
    plugins: {
      legend: { display: false },
      title: {
        display: true,
        text: "Chart JS Line Chart",
      },
    },

    scales: {
      x: {
        position: "bottom",
        title: {
          display: true,
          text: "Time (seconds) live",
        },
      },
      y: {
        title: {
          display: true,
          text: "Data Points",
        },
      },
    },
  };

  // On Mount
  // useEffect(() => {
  //   const startTime = performance.now();

  //   const simulateChartLoad = () => {
  //     return new Promise((resolve) =>
  //       setTimeout(resolve, Math.random() * 1000 + 500)
  //     );
  //   };

  //   simulateChartLoad().then(() => {
  //     const endTime = performance.now();
  //     const timeTaken = endTime - startTime;
  //     setLoadTime(timeTaken);
  //   });
  // }, []);
  return (
    <Container
      maxWidth="lg"
      sx={{
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Typography>
        Load Time:{" "}
        <strong>{loadTime ? (loadTime / 1000).toFixed(2) : 0}s</strong>
      </Typography>
      <Line
        data={chartData}
        options={options}
        style={{
          maxHeight: 400,
        }}
      />
      <Typography marginY={2}>
        If you need simple set of charts with minimal configurations without
        paying a dime, this is the option you should choose. Smaller bundle size
        of this library gives it extra brownie points. However, as your project
        and team size grows and complexity of the data viz needs increases, you
        may have to consider alternatives.
      </Typography>
    </Container>
  );
};
export default ChartJSLineChart;
