import { AsyncDuckDBConnection } from "@duckdb/duckdb-wasm";
import { QueryResult, TableData } from "duckdb";
import { ArrowSchema } from "parquet-wasm";
import React, { useCallback, useEffect, useMemo, useState } from "react";

const useDuckDB = (
  duckDBService: (path: string) => Promise<{
    connection: AsyncDuckDBConnection;
    jsonTable: string;
  }>,
  servicePath: string
): [string, (query: string) => Promise<any>, string] => {
  const [duckDbConnection, setDuckDbConnection] =
    useState<AsyncDuckDBConnection>();

  const [tableName, setTableName] = useState<string>("");
  const [error, setError] = useState("");

  const initializeDuckDb = useCallback(async () => {
    try {
      const db = await duckDBService(servicePath);

      setDuckDbConnection(db.connection);
      setTableName(db.jsonTable);
    } catch (error: any) {
      console.error(error);
      setError(error.message);
    }
  }, [duckDBService, servicePath]);

  useEffect(() => {
    initializeDuckDb();
  }, [initializeDuckDb]);

  const getData = useCallback(
    async (query: string) => {
      try {
        const result = await duckDbConnection?.query(query);

        await duckDbConnection?.close();
        return result;
      } catch (error) {
        await duckDbConnection?.close();
        return [];
      }
    },
    [duckDbConnection]
  );

  return [tableName, getData, error];
};

export default useDuckDB;
