import * as duckdb from "@duckdb/duckdb-wasm";

const initDuckDB = async () => {
  const JSDELIVR_BUNDLES = duckdb.getJsDelivrBundles();

  // Select a bundle based on browser checks
  const bundle = await duckdb.selectBundle(JSDELIVR_BUNDLES);

  const worker_url = URL.createObjectURL(
    new Blob([`importScripts("${bundle.mainWorker!}");`], {
      type: "text/javascript",
    })
  );

  // Instantiate the asynchronus version of DuckDB-wasm
  const worker = new Worker(worker_url);
  const logger = new duckdb.ConsoleLogger();
  const db = new duckdb.AsyncDuckDB(logger, worker);
  await db.instantiate(bundle.mainModule, bundle.pthreadWorker);
  URL.revokeObjectURL(worker_url);
  return db;
};

// INITIALIZE DUCKDB ON DUCKDB-WASM-KIT = NOT ABLE TO SAVE ON CLIENT SIDE STATE
// TODO: SAVED FOR NOW FOR DOCUMENTATION PURPOSE, WILL DELETE THIS LATER
// export const initMetricsData = async (
//   filePath: string
// ): Promise<{ connection: duckdb.AsyncDuckDBConnection; jsonTable: string }> => {
//   const response = await fetch(filePath);
//   (await duckDB).registerFileBuffer(
//     "buffer.parquet",
//     new Uint8Array(await response.arrayBuffer())
//   );

//   const connect = (await duckDB).connect();

//   (await connect).query(
//     `CREATE OR REPLACE TABLE new_table AS SELECT * FROM "buffer.parquet"`
//   );
//   (await connect).query(`COPY (SELECT * FROM new_table) TO 'data.json' `);

//   //   (await connect).query(
//   //     `CREATE OR REPLACE TABLE metric_data AS SELECT * FROM 'data.json'`
//   //   );

//   return {
//     connection: await connect,
//     jsonTable: "data.json",
//   };
// };

// INITIALIZE DUCKDB ON DUCKDB-WASM
export const initData = async (
  filePath: string
): Promise<{ connection: duckdb.AsyncDuckDBConnection; jsonTable: string }> => {
  const newDB: duckdb.AsyncDuckDB = await initDuckDB();
  const response = await fetch(filePath);
  await newDB.registerFileBuffer(
    "buffer.parquet",
    new Uint8Array(await response.arrayBuffer())
  );

  const connect = await newDB.connect();

  await connect.query(
    `CREATE OR REPLACE TABLE new_table AS SELECT * FROM "buffer.parquet"`
  );

  await connect.query(`COPY (SELECT * FROM new_table) TO 'data.json'`);

  return {
    connection: connect,
    jsonTable: "data.json",
  };
};

export const initializeDuckDB = async (): Promise<duckdb.AsyncDuckDB> => {
  const newDB: duckdb.AsyncDuckDB = await initDuckDB();

  return newDB;
};
