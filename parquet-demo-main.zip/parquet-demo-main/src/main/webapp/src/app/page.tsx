"use client";
import * as React from "react";
import Avatar from "@mui/material/Avatar";
import CssBaseline from "@mui/material/CssBaseline";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";

import Container from "@mui/material/Container";
import { FolderZip } from "@mui/icons-material";
import useDuckDB from "@/hooks/useDuckDB";
import { initData } from "@/duckDBService/metrics";
import HighchartsLineChart from "@/components/high-charts/HighchartsLineChart";
import moment from "moment";
import ChartJSLineChart from "@/components/chartjs/ChartJSLineChart";
import GoogleLineChart from "@/components/google-charts/GoogleLineChart";
import ChartFilters from "@/components/chartTools/ChartFilters";
import { CircularProgress } from "@mui/material";

const Home = () => {
  const [jsonData, setJsonData] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(false);

  // const [jsonTable, getData, error] = useDuckDB(
  //   initData,
  //   "/data_20200601.parquet"
  // );

  // const queryData = React.useCallback(async () => {
  //   try {
  //     const result = await getData(
  //       `SELECT * FROM  read_json_auto(${jsonTable}, FORMAT='auto')`
  //     );
  //     const data: any[] = result ? JSON.parse(await result?.toString()) : [];
  //     const datasets = data.map(
  //       (item: { myString: string; myInteger: number; myDateTime: string }) => {
  //         const transformDate = moment(item.myDateTime, "YYYY-MM-DD HH:mm:sz");
  //         const timeStamp = transformDate.unix();
  //         return [timeStamp, item.myInteger];
  //       }
  //     );

  //     setJsonData(datasets);
  //     setLoading(false);
  //   } catch (error) {
  //     setJsonData([]);
  //     setLoading(false);
  //   }
  // }, [jsonTable]);

  // React.useEffect(() => {
  //   queryData();
  // }, [queryData]);
  return (
    <Container component="main">
      <CssBaseline />
      <Box
        sx={{
          marginTop: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <ChartFilters
          setLoading={setLoading}
          loading={loading}
          setJsonData={setJsonData}
        />
        {loading ? (
          <Box
            width={"100%"}
            height={"50vh"}
            sx={{
              display: "grid",
              placeItems: "center",
            }}
          >
            <CircularProgress />
          </Box>
        ) : (
          <>
            {jsonData.length > 0 && (
              <Box
                width={"100%"}
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  gap: 2,
                }}
              >
                {/* <HighchartsLineChart data={jsonData} /> */}
                <ChartJSLineChart data={jsonData} />
                {/* <GoogleLineChart data={jsonData} /> */}
              </Box>
            )}
          </>
        )}
      </Box>
    </Container>
  );
};

export default Home;
