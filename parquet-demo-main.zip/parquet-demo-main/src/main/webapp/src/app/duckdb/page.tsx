"use client";
import * as React from "react";
import Avatar from "@mui/material/Avatar";
import CssBaseline from "@mui/material/CssBaseline";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";

import Container from "@mui/material/Container";
import { FolderZip } from "@mui/icons-material";
import * as duckdb from "@duckdb/duckdb-wasm";

interface ParquetRecords {
  [key: string]: any;
}

const Home = () => {
  const [jsonData, setJsonData] = React.useState<ParquetRecords[]>([]);
  const [duckDbConnection, setDuckDbConnection] =
    React.useState<duckdb.AsyncDuckDB | null>(null);

  const readParquet = async () => {
    try {
      const response = await fetch(`/data_20200601.parquet`);
      await duckDbConnection?.registerFileBuffer(
        "buffer.parquet",
        new Uint8Array(await response.arrayBuffer())
      );
      const connect = await duckDbConnection?.connect();

      await connect?.query(`
   CREATE TABLE my_table AS SELECT * FROM "buffer.parquet";
`);

      await connect?.query(`
  COPY (SELECT * FROM my_table) TO 'data.json'
`);

      const result = await connect?.query(`
 SELECT * FROM 'data.json' LIMIT 100
`);
      connect?.close();
      const data: any[] = JSON.parse(result?.toString() as string);

      setJsonData(data);
    } catch (error) {
      console.log(error, "err");
    }
  };

  React.useEffect(() => {
    if (typeof window === "undefined") return;
    const init = async () => {
      const MANUAL_BUNDLES: duckdb.DuckDBBundles = {
        mvp: {
          mainModule:
            "https://cdn.jsdelivr.net/npm/@duckdb/duckdb-wasm@1.28.1-dev99.0/dist/duckdb-mvp.wasm",
          mainWorker:
            "https://cdn.jsdelivr.net/npm/@duckdb/duckdb-wasm@1.28.1-dev99.0/dist/duckdb-browser-mvp.worker.js",
        },
        eh: {
          mainModule:
            "https://cdn.jsdelivr.net/npm/@duckdb/duckdb-wasm@1.28.1-dev99.0/dist/duckdb-eh.wasm",
          mainWorker:
            "https://cdn.jsdelivr.net/npm/@duckdb/duckdb-wasm@1.28.1-dev99.0/dist/duckdb-browser-eh.worker.js",
        },
      };

      const bundle = await duckdb.selectBundle(MANUAL_BUNDLES);
      const worker_url = URL.createObjectURL(
        new Blob([`importScripts("${bundle.mainWorker!}");`], {
          type: "text/javascript",
        })
      );
      // Instantiate the asynchronus version of DuckDB-wasm
      const worker = new Worker(worker_url);
      const logger = new duckdb.ConsoleLogger();
      const db = new duckdb.AsyncDuckDB(logger, worker);
      await db.instantiate(bundle.mainModule, bundle.pthreadWorker);
      setDuckDbConnection(db);
    };

    init();
  }, []);

  React.useEffect(() => {
    if (!duckDbConnection) return;
    readParquet();
  }, [duckDbConnection]);

  return (
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <Box
        sx={{
          marginTop: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Avatar sx={{ m: 1, bgcolor: "secondary.main" }}>
          <FolderZip />
        </Avatar>
        <Typography component="h1" variant="h5" mb={2}>
          Generate Parquet Data
        </Typography>

        {jsonData.map((record, index) => (
          <div key={index}>{JSON.stringify(record)}</div>
        ))}
      </Box>
    </Container>
  );
};

export default Home;
