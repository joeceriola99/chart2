// "use client";
// import * as React from "react";
// import Avatar from "@mui/material/Avatar";
// import CssBaseline from "@mui/material/CssBaseline";
// import Box from "@mui/material/Box";
// import Typography from "@mui/material/Typography";
// import Container from "@mui/material/Container";
// import { FolderZip } from "@mui/icons-material";
// import { initializeDuckDb, useDuckDb, useDuckDbQuery } from "duckdb-wasm-kit";
// import { DuckDBConfig } from "@duckdb/duckdb-wasm";
// const fields = [
//   {
//     name: "region",
//     label: "Region",
//   },
//   {
//     name: "instance_id",
//     label: "Instance ID",
//   },
//   {
//     name: "cluster_id",
//     label: "Cluster ID",
//   },
//   {
//     name: "container_ID",
//     label: "Container_ID",
//   },
//   {
//     name: "content_id",
//     label: "Content ID",
//   },
//   {
//     name: "session_id",
//     label: "Session ID",
//   },
// ];

// interface ParquetRecords {
//   [key: string]: any;
// }

// const Home = () => {
//   const [jsonData, setJsonData] = React.useState<ParquetRecords[]>([]);
//   const { arrow, loading, error } = useDuckDbQuery(`
//       CREATE TABLE my_table AS SELECT * FROM "http://localhost:3000/data_20200601.parquet"
//     `);
//   const {
//     arrow: table,
//     loading: isLoading,
//     error: err,
//   } = useDuckDbQuery(`
//       SELECT * FROM my_table
//     `);
//   console.log(JSON.stringify(table, null, 2), isLoading, err);
//   return (
//     <Container component="main" maxWidth="xs">
//       <CssBaseline />
//       <Box
//         sx={{
//           marginTop: 8,
//           display: "flex",
//           flexDirection: "column",
//           alignItems: "center",
//         }}
//       >
//         <Avatar sx={{ m: 1, bgcolor: "secondary.main" }}>
//           <FolderZip />
//         </Avatar>
//         <Typography component="h1" variant="h5" mb={2}>
//           Generate Parquet Data
//         </Typography>
//         {/* TODO HANDLE THE GENERATE WITH FORM */}
//         {/* <Box component="form" noValidate onSubmit={handleSubmit} sx={{ mt: 3 }}>
//           <Grid container spacing={2}>
//             {fields.map((field) => (
//               <Grid item xs={12}>
//                 <TextField
//                   name={field.name}
//                   fullWidth
//                   id={field.name}
//                   label={field.label}
//                 />
//               </Grid>
//             ))}
//           </Grid>
//           <Button
//             type="submit"
//             fullWidth
//             variant="contained"
//             sx={{ mt: 3, mb: 2 }}
//           >
//             Submit
//           </Button>
//         </Box> */}
//         {jsonData.map((record, index) => (
//           <div key={index}>{JSON.stringify(record)}</div>
//         ))}
//       </Box>
//     </Container>
//   );
// };

// export default Home;
