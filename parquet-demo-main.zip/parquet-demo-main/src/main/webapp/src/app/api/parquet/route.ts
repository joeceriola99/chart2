// import { NextApiRequest, NextApiResponse } from "next";
// import DuckDB from "duckdb";

// export default async (req: NextApiRequest, res: NextApiResponse) => {
//   const db = new DuckDB();

//   let cursor = reader.getCursor();
//   let record = null;
//   let jsonArray = [];

//   while ((record = await cursor.next())) {
//     jsonArray.push(record);
//   }
//   console.log(jsonArray, "Arr");
//   await reader.close();
//   res.status(200).json(jsonArray);
// };
