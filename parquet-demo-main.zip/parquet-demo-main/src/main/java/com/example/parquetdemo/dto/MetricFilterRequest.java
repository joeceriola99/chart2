package com.example.parquetdemo.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MetricFilterRequest {
    private String region;
    private String clusterId;
    private String instanceId;
    private String containerId;
    private String contentId;
    private String sessionId;
    private String sessionTime;
    private String networkType;
    private String mcc;
    private String mnc;
    private String startTime;
    private String endTime;
    private String modelName;
}

