package com.example.parquetdemo.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
public class ResponseWrapper {

    @Autowired
    MessageSource messageSource;

    public ResponseHead getResponseHead(MessageCode messageCode, Object[] args) {

        String message = messageSource.getMessage(messageCode.getMessageCode(), null,
            Locale.getDefault());

        return new ResponseHead(messageCode.getMessageCode(), message);
    }
}
