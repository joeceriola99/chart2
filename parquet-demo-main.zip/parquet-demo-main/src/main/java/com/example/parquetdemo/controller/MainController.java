package com.example.parquetdemo.controller;

import com.example.parquetdemo.dto.*;
import com.example.parquetdemo.service.MetricsMonitoringService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/out")
public class MainController {

    @NonNull
    private ResponseWrapper wrapper;

    @Autowired
    private MetricsMonitoringService metricsMonitoringService;

    @Operation(summary = "Get historical metric data")
    @GetMapping("/metrics")

    public ResponseEntity<Response<ContainerHistoricalMetricResponseDto>> getHistoricalMetricData(
            @RequestParam(value = "region") String regionCode,
            @RequestParam(value = "cluster_id") String instanceName,
            @RequestParam(value = "instance_id") String instanceId,
            @RequestParam(value = "container_id") String containerId,
            @RequestParam(value = "content_id") String contentId,
            @RequestParam(value = "session_id") String sessionId,
            @RequestParam(value = "from") String from,
            @RequestParam(value = "to") String to) {
        MetricFilterRequest request = MetricFilterRequest.builder()
                .region(regionCode)
                .clusterId(instanceName)
                .instanceId(instanceId)
                .containerId(containerId)
                .contentId(contentId)
                .sessionId(sessionId)
                .startTime(from)
                .endTime(to)
                .build();
        ContainerHistoricalMetricResponseDto histMetric =
                metricsMonitoringService.getHistoricalMetrics(request);
        return ResponseEntity.ok(
                new Response<>(wrapper.getResponseHead(MessageCode.OK, null), histMetric));
    }
}
