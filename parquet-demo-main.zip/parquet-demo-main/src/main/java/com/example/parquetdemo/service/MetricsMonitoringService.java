package com.example.parquetdemo.service;

import com.example.parquetdemo.constant.ContainerMetrics;
import com.example.parquetdemo.dto.ContainerHistoricalMetricResponseDto;
import com.example.parquetdemo.dto.ContainerMetricResponse;
import com.example.parquetdemo.dto.MetricFilterRequest;
import com.influxdb.client.InfluxDBClient;
import com.influxdb.query.FluxRecord;
import com.influxdb.query.FluxTable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

import static com.example.parquetdemo.dto.ContainerHistoricalMetricResponseDto.*;

@Slf4j
@Service
public class MetricsMonitoringService {

    @Autowired
    @Qualifier("influxDBClient")
    private InfluxDBClient influxDBClient;

    @Autowired
    private Environment environment;

    public ContainerHistoricalMetricResponseDto getHistoricalMetrics(MetricFilterRequest request) {

        String query = generateTimeRangeQuery(request);
        /** TODO: Check MAP to POJO
         List<Metric> metrics = influxDBClient.getQueryApi().query(query, Metric.class);
         for(Metric m: metrics) {
         System.out.println("region: " + m.region + ", container_id:" + m.containerId + ", packetloss: " + m.packetloss + ", packet:" + m.packet + ", bandwidth: " + m.bandwidth + ", fps: " + m.fps);
         }
         **/
        List<FluxTable> tables = influxDBClient.getQueryApi().query(query, environment.getProperty("influx.monitor.org"));
        //TODO add parquet mapping
        return fromFluxTables(tables, request.getRegion(), request.getContainerId(),
                request.getContentId(), request.getClusterId());
    }

    private String generateTimeRangeQuery(MetricFilterRequest request) {
        log.debug("Querying TSDB for Historical Data -- Starting: " + request.getStartTime() + "Ending: " + request.getEndTime());
        String query = "from(bucket: \"" + environment.getProperty("influx.monitor.bucket") + "\")" +
                "  |> range(start: time(v:\"" + request.getStartTime() + "\"), stop: time(v:\"" + request.getEndTime() + "\"))" +
                "  |> filter(fn: (r) => r[\"_measurement\"] == \"" + environment.getProperty("metric.version") +"\")"+
                "  |> filter(fn: (r) => r[\"region\"] == \"" + request.getRegion() + "\")" +
                "  |> filter(fn: (r) => r[\"cluster_id\"] == \"" + request.getClusterId() + "\")" +
                "  |> filter(fn: (r) => r[\"private_ip\"] == \"" + request.getInstanceId() + "\")" +
                "  |> filter(fn: (r) => r[\"container_id\"] == \"" + request.getContainerId() + "\")" +
                "  |> filter(fn: (r) => r[\"content_id\"] == \"" + request.getContentId() + "\")" +
                "  |> filter(fn: (r) => r[\"sessionId\"] == \"" + request.getSessionId() + "\")";
        log.debug("Executing query: " + query);
        return query;
    }

    public ContainerHistoricalMetricResponseDto fromFluxTables(List<FluxTable> tables, String region, String containerId,
                                                               String contentId, String instanceName) {
        ContainerHistoricalMetricResponseDto response = new ContainerHistoricalMetricResponseDto();
        if (tables.size() > 0) {
            FluxRecord record = tables.get(0).getRecords().get(0);
            response.setMnc(String.valueOf(record.getValueByKey("mnc")));
            response.setMcc(String.valueOf(record.getValueByKey("mcc")));
            response.setNetworkType(String.valueOf(record.getValueByKey("network_type")));
            response.setModelName(String.valueOf(record.getValueByKey("model")));
            response.setSessionId(String.valueOf(record.getValueByKey("sessionId")));
            response.setUseTurnServer(Boolean.valueOf(String.valueOf(record.getValueByKey("is_use_turn_server"))));
        }
//        response.setGameName(getGameNameByContentId(contentId));
        response.setServerId(instanceName);
        response.setRegion(region);
        response.setContainerId(containerId);
        response.setContentId(contentId);
        MetricDataHistoryDto data = getMetricDataDto(tables, response);
        response.setData(data);
        return response;
    }
    private MetricDataHistoryDto getMetricDataDto(List<FluxTable> tables, ContainerMetricResponse response) {
        MetricDataHistoryDto data = new MetricDataHistoryDto();
        for(FluxTable table: tables) {
            List<FluxRecord> records = table.getRecords();
            try {
                ContainerMetrics columnName = ContainerMetrics.valueOf(records.get(0).getField().toUpperCase().strip());
                switch (columnName) {
                    case CONTENT_ID:
                        String contentId = String.valueOf(records.get(0).getValueByKey(ContainerMetrics.CONTENT_ID.getValue()));
                        log.debug("Acquired content_id data from time series database: " + contentId);
                        response.setContentId(contentId);
                        response.setTimestamp(String.valueOf(records.get(0).getStart().getEpochSecond()));
                        break;
                    case BANDWIDTH :
                        log.debug("Acquired bandwidth data from time series database.");
                        data.bandwidth.add(getMetricData(records));
                        break;
                    case FIR:
                        log.debug("Acquired fir data from time series database.");
                        data.fir.add(getMetricData(records));
                        break;
                    case FPS:
                        log.debug("Acquired fps data from time series database.");
                        data.fps.add(getMetricData(records));
                        break;
                    case NACK:
                        log.debug("Acquired nack data from time series database.");
                        data.nack.add(getMetricData(records));
                        break;
                    case PACKET:
                        log.debug("Acquired packet data from time series database.");
                        data.packet.add(getMetricData(records));
                        break;
                    case PACKET_LOSS:
                        log.debug("Acquired packet_loss data from time series database.");
                        data.packetloss.add(getMetricData(records));
                        break;
                    case JITTER:
                        log.debug("Acquired jitter data from time series database.");
                        data.jitter.add(getMetricData(records));
                        break;
                    case FRAME_DROP:
                        log.debug("Acquired frame_drop data from time series database.");
                        data.framedrop.add(getMetricData(records));
                        break;
                    case RTT:
                        log.debug("Acquired rtt data from time series database.");
                        data.rtt.add(getMetricData(records));
                        break;
                    case PLI:
                        log.debug("Acquired pli data from time series database.");
                        data.pli.add(getMetricData(records));
                        break;
                    case ASSEMBLY_TOTAL:
                        log.debug("Acquired total_assembly_time data from time series database.");
                        data.totalAssemblyTime.add(getMetricData(records));
                        break;
                    case ASSEMBLY_TIME_PER_FRAME:
                        log.debug("Acquired assembly_time_per_frame data from time series database.");
                        data.assemblyTimePerFrame.add(getMetricData(records));
                        break;
                    default:
                        log.debug("Acquired additional metric to map: " + columnName);
                        break;
                }
            } catch (IllegalArgumentException e) {
                log.debug("Unknown/TSDB specific metric field is automatically skipped." + e.getMessage());
            }
        }
        return data;
    }

    private MetricData getMetricData(List<FluxRecord> records) {
        MetricData metricData = new MetricData();
        metricData.setData(fillMetricDataPoint(records));
        metricData.setStart(records.get(0).getTime().getEpochSecond());
        metricData.setEnd(records.get(records.size()-1).getTime().getEpochSecond());
        return metricData;
    }

    public MetricDataPointDto[] fillMetricDataPoint(List<FluxRecord> records) {
        List<MetricDataPointDto> values = new LinkedList<>();
        Iterator<FluxRecord> metrics = records.iterator();
        while(metrics.hasNext()) {
            FluxRecord record = metrics.next();
            Instant timestamp = (Instant) record.getValueByKey("_time");
            if (Objects.nonNull(record.getValue())) {
                BigDecimal decimalValue = new BigDecimal(String.valueOf(record.getValue()));
                Float value = decimalValue.setScale(8, RoundingMode.HALF_UP).floatValue();
                values.add(new MetricDataPointDto(value, timestamp.getEpochSecond()));
            }
        }
        return values.toArray(MetricDataPointDto[] ::new);
    }
}
