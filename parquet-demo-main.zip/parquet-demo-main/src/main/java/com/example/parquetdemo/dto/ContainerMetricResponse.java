package com.example.parquetdemo.dto;

public interface ContainerMetricResponse {
    void setTimestamp(String timestamp);
    void setContentId(String contentId);
}
