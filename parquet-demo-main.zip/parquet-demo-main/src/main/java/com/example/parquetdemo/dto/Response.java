package com.example.parquetdemo.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Response<T> {

    private ResponseHead result;

    @Schema(description = "Actual response data", required = false)
    private T detail;

    public Response(ResponseHead result) {
        this.result = result;
        this.detail = null;
    }

    public Response(ResponseHead result, T detail) {
        this.result = result;
        this.detail = detail;
    }

    public Response(MessageCode messageCode, Object[] args) {

        this.result = new ResponseHead(messageCode.getMessageCode(), "");
        this.detail = null;
    }

    public Response(MessageCode messageCode, Object[] args, T detail) {
        this.result = new ResponseHead(messageCode.getMessageCode(), "");
        this.detail = detail;
    }


}
