package com.example.parquetdemo.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ContainerHistoricalMetricResponseDto implements Serializable, ContainerMetricResponse{
    private String region;
    private String containerId;
    private String timestamp;
    private String serverId;
    private String contentId;
    private String mnc;
    private String mcc;
    private String networkType;
    private String modelName;
    private String sessionId;
    private String gameName;
    private boolean isUseTurnServer;
    private MetricDataHistoryDto data;

    @Data
    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    @NoArgsConstructor
    public static class MetricDataHistoryDto {

        public List<MetricData> bandwidth = new ArrayList<>();
        public List<MetricData> fps = new ArrayList<>();
        public List<MetricData> jitter = new ArrayList<>();
        public List<MetricData> packet = new ArrayList<>();
        public List<MetricData> packetloss = new ArrayList<>();
        public List<MetricData> framedrop = new ArrayList<>();
        public List<MetricData> nack = new ArrayList<>();
        public List<MetricData> pli = new ArrayList<>();
        public List<MetricData> fir = new ArrayList<>();
        public List<MetricData> rtt = new ArrayList<>();
        public List<MetricData> totalAssemblyTime = new ArrayList<>();
        public List<MetricData> assemblyTimePerFrame = new ArrayList<>();

    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    @NoArgsConstructor
    @JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
    public static class MetricData {
            public MetricDataPointDto[] data;
            public Long start;
            public Long end;
            public String contentId;
    }

    @Data
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    public static class MetricDataPointDto {
        Float data;
        Long time;
    }

}
