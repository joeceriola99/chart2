package com.example.parquetdemo.constant;

public enum ContainerMetrics {
    CONTENT_ID("content_id"),
    BANDWIDTH("bandwidth"),
    PACKET_LOSS("packet_loss"),
    FIR("fir"),
    FPS("fps"),
    NACK("nack"),
    JITTER("jitter"),
    RTT("rtt"),
    PLI("pli"),
    FRAME_DROP("frame_drop"),
    PACKET("packet"),
    SESSION_TIME("session_time"),
    MNC("mnc"),
    MCC("mcc"),
    MODEL("model"),
    NETWORK_TYPE("network_type"),
    ASSEMBLY_TOTAL("total_assembly_time"),
    ASSEMBLY_TIME_PER_FRAME("assembly_time_per_frame");;

    private final String value;

    ContainerMetrics(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
