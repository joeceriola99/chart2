package com.example.parquetdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParquetDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParquetDemoApplication.class, args);
	}

}
