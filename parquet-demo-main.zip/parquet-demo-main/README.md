# parquet-demo
Project to test parquet encoding decoding and chart integration
